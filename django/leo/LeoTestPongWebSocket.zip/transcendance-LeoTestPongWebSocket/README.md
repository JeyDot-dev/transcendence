# transcendance
Dependencies:
pip3 install channels django daphne

Test sur localhost:8000/:
python3 manage.py runserver 

Commit uuid: uuid generé dans le front a changer a terme